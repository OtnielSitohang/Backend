const PDFDocument = require('pdfkit');
const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
const Booking = require('../models/Booking');
const db = require('../config'); 


// Fungsi untuk membuat booking
exports.bookField = async (req, res) => {
  try {
    const { pengguna_id, lapangan_id, jenis_lapangan_id, tanggal_booking, tanggal_penggunaan, sesi, foto_base64, harga } = req.body;

    // Query untuk melakukan booking dengan data yang diterima dari request body
    const query = `
      INSERT INTO booking (pengguna_id, lapangan_id, jenis_lapangan_id, tanggal_booking, tanggal_penggunaan, sesi, bukti_pembayaran, harga)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [pengguna_id, lapangan_id, jenis_lapangan_id, tanggal_booking, tanggal_penggunaan, sesi, foto_base64, harga];

    // Jalankan query dengan data yang diterima
    db.query(query, values, (error, results) => {
      if (error) {
        console.error('Error executing query:', error);
        res.status(500).json({ message: 'Error creating booking' });
      } else {
        res.status(201).json({ message: 'Booking created successfully' });
      }
    });
  } catch (error) {
    console.error('Error creating booking:', error);
    res.status(500).json({ message: 'Error creating booking' });
  }
};
// Fungsi untuk mendapatkan booking berdasarkan ID
exports.getBookingById = (req, res) => {
  Booking.findById(req.params.bookingId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Booking with id ${req.params.bookingId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving Booking with id " + req.params.bookingId
        });
      }
    } else {
      res.send(data);
    }
  });
};

// Fungsi untuk mendapatkan semua booking
exports.getAllBookings = (req, res) => {
  Booking.getAll((err, data) => {
    if (err) {
      console.error("Error retrieving bookings: ", err);
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving bookings."
      });
    } else {
      res.send(data);
    }
  });
};

// Fungsi untuk mengonfirmasi booking dan mengirimkan invoice
exports.confirmBooking = (req, res) => {
  Booking.updateStatusKonfirmasi(req.params.bookingId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found Booking with id ${req.params.bookingId}.`
        });
      } else {
        res.status(500).send({
          message: "Error updating Booking with id " + req.params.bookingId
        });
      }
    } else {
      res.send(data);
    }
  });
};

// Fungsi untuk mendapatkan booking dengan filter
exports.getBookings = async (req, res) => {
  try {
    const filters = {
      tanggal_penggunaan: req.query.tanggal_penggunaan,
      jenis_lapangan_id: req.query.jenis_lapangan_id,
      status_konfirmasi: req.query.status_konfirmasi,
    };
    
    const results = await Booking.getBookings(filters);
    res.json(results);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};


exports.checkAvailability = async (req, res) => {
  try {
    const { jenis_lapangan_id, tanggal_penggunaan, sesi } = req.body;

    // Debugging: Print received data
    console.log('Received data:', { jenis_lapangan_id, tanggal_penggunaan, sesi });

    // Query untuk mengecek ketersediaan lapangan
    const query = `
      SELECT id, nama_lapangan, harga
      FROM lapangan
      WHERE jenis_lapangan_id = ? 
        AND id NOT IN (
          SELECT lapangan_id
          FROM booking
          WHERE jenis_lapangan_id = ?
            AND tanggal_penggunaan = ?
            AND sesi = ?
        )
    `;
    db.query(query, [jenis_lapangan_id, jenis_lapangan_id, tanggal_penggunaan, sesi], (error, results) => {
      if (error) {
        console.error('Error checking field availability:', error);
        res.status(500).json({ message: 'Internal server error' });
        return;
      }
      
      // Menyusun data lapangan yang tersedia dengan harga
      const lapanganAvailable = results.map(({ id, nama_lapangan, harga }) => ({
        id,
        nama_lapangan,
        harga
      }));
      
      res.status(200).json(lapanganAvailable);
    });
  } catch (error) {
    console.error('Error checking field availability:', error);
    res.status(500).json({ message: 'Internal server error' });
  }
};



exports.bookField = async (req, res) => {
  try {
    const { pengguna_id, lapangan_id, jenis_lapangan_id, tanggal_booking, tanggal_penggunaan, sesi, foto_base64, harga } = req.body;

    // Query untuk melakukan booking dengan data yang diterima dari request body
    const query = `
      INSERT INTO booking (pengguna_id, lapangan_id, jenis_lapangan_id, tanggal_booking, tanggal_penggunaan, sesi, bukti_pembayaran, harga)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [pengguna_id, lapangan_id, jenis_lapangan_id, tanggal_booking, tanggal_penggunaan, sesi, foto_base64, harga];

    // Jalankan query dengan data yang diterima
    db.query(query, values, (error, results) => {
      if (error) {
        console.error('Error executing query:', error);
        res.status(500).json({ message: 'Error creating booking' });
      } else {
        res.status(201).json({ message: 'Booking created successfully' });
      }
    });
  } catch (error) {
    console.error('Error creating booking:', error);
    res.status(500).json({ message: 'Error creating booking' });
  }
};